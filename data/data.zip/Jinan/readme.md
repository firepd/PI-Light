Jinan 3x4 


Dataset from CoLight